# Guía mínima de SQL

## Qué es SQL

SQL es un lenguaje para consultar y transformar información organizada en tablas.
La consulta describe el resultado buscado; el motor decide cómo ejecutarla.

No reemplaza la pregunta de negocio ni corrige un grano mal entendido.

## Anatomía de una consulta

```sql
SELECT
    familia,
    ROUND(SUM(venta_neta), 2) AS ventas
FROM vw_ventas
WHERE region = 'Patagonia'
GROUP BY familia
ORDER BY ventas DESC;
```

| Cláusula | Función |
|---|---|
| `SELECT` | elige columnas o calcula métricas |
| `FROM` | define tabla o vista de origen |
| `WHERE` | filtra filas antes de agrupar |
| `GROUP BY` | define el nivel del resumen |
| `ORDER BY` | ordena la salida |
| `LIMIT` | restringe cuántas filas se muestran |

## Funciones iniciales

```sql
COUNT(*)                    -- filas
COUNT(DISTINCT pedido)      -- pedidos diferentes
SUM(venta_neta)             -- suma
AVG(cantidad)               -- promedio simple
MIN(fecha_pedido)           -- mínimo
MAX(fecha_pedido)           -- máximo
ROUND(valor, 2)             -- presentación con dos decimales
```

Antes de usar una función, completá la frase: “Estoy contando o sumando
__________”.

## Crear una categoría

```sql
CASE
    WHEN descuento_pct = 0 THEN 'Sin descuento'
    WHEN descuento_pct <= 0.05 THEN 'Hasta 5 %'
    ELSE 'Más de 5 %'
END AS banda_descuento
```

Las reglas se evalúan de arriba hacia abajo. Deben ser explícitas y no superponerse
de manera accidental.

## Qué es un join

Un join combina filas de dos tablas mediante una condición.

```sql
SELECT
    o.order_number,
    c.customer_name
FROM sales_orders AS o
INNER JOIN customers AS c
    ON o.customer_id = c.customer_id;
```

- `o` y `c` son alias breves.
- `ON` expresa la regla de vinculación.
- La clave del lado “uno” debe ser única.
- Después del join se comparan filas y claves.

## Controles mínimos

```sql
SELECT
    COUNT(*) AS filas,
    COUNT(DISTINCT line_id) AS lineas
FROM resultado;
```

Para importes:

```sql
SELECT
    ROUND(SUM(venta_neta), 2) AS ventas
FROM resultado;
```

No interpretes una salida hasta verificar que el grano esperado se conserva.

## Errores frecuentes

| Síntoma | Primera revisión |
|---|---|
| “column not found” | nombre del campo y tabla |
| salida vacía | valor y condición de `WHERE` |
| ventas duplicadas | cardinalidad y condición del join |
| pedido repetido | puede ser correcto si el grano es línea |
| promedio extraño | confirmar si debe ponderarse |
| margen porcentual incorrecto | usar `SUM(margen) / SUM(venta)`, no promedio simple |

## Cómo usar IA con criterio

Una buena solicitud incluye:

1. grano de cada tabla;
2. campos disponibles;
3. pregunta;
4. salida o mensaje de error;
5. control esperado.

Pedí también que explique:

- qué cuenta o suma;
- qué filas filtra;
- qué relación usa;
- cómo verificar que no duplica.

Ejecutá y controlá la respuesta: una consulta plausible no es evidencia hasta que
produce una salida reconciliada.
