# Faro Sur — Paquete B: cómo empezar

## Qué necesitás

- una notebook personal;
- un navegador actualizado;
- una cuenta Google;
- conexión a internet;
- los archivos de esta carpeta.

No necesitás instalar Python ni una base de datos. Tampoco necesitás GCP, una clave
de API, Power BI o una computadora con Windows para estas prácticas.

## Un solo archivo de datos

Para ambos notebooks se usa:

`datos/datos_faro_sur_b_v1.0.zip`

No lo descomprimas antes de cargarlo en Colab. El notebook lo hará y comprobará que
contenga:

- `customers.csv`;
- `products.csv`;
- `sales_orders.csv`;
- `sales_order_lines.csv`;
- `vw_ventas.csv`.

## Recorrido recomendado

### Paso 1 — comprender el modelo

Abrí:

- `Diagrama modelo relacional - Faro Sur - Paquete B.png`;
- la hoja `Tablas` del diccionario Excel.

Antes de ejecutar código, deberías poder explicar qué representa una fila en cada
tabla.

### Paso 2 — SQL sin joins

1. Descargá `Faro_Sur_02_SQL_sobre_una_vista.ipynb`.
2. Ingresá a https://colab.research.google.com/.
3. Elegí **Archivo → Subir notebook**.
4. Guardá una copia propia en Drive.
5. Ejecutá las celdas de arriba hacia abajo.
6. Cuando se abra el selector, cargá únicamente
   `datos_faro_sur_b_v1.0.zip`.
7. Detenete si el control no muestra 7.500 filas y 3.574 pedidos.

La vista `vw_ventas` ya reúne los campos. Tu tarea es cambiar filtros,
agrupaciones y dimensiones, no escribir relaciones todavía.

### Paso 3 — un join por vez

En otra copia de Colab, abrí
`Faro_Sur_03_Modelo_y_joins_controlados.ipynb` y cargá el mismo ZIP.

El recorrido construye:

1. pedidos con clientes;
2. líneas con productos;
3. el detalle de las cuatro tablas;
4. una reconciliación contra la vista.

## Controles esperados

| Control | Esperado |
|---|---:|
| Clientes | 120 |
| Productos | 30 |
| Pedidos | 3.574 |
| Líneas | 7.500 |
| Venta neta | USD 32.825.861,00 |
| Margen bruto | USD 9.038.105,00 |

Un resultado distinto no se interpreta: primero se revisa la carga, el grano o el
join.

## Si algo falla

1. Leé el último mensaje de error completo.
2. Confirmá que cargaste el ZIP, no un CSV individual.
3. Confirmá que el archivo conserva el nombre
   `datos_faro_sur_b_v1.0.zip`.
4. Reiniciá la sesión y ejecutá desde la primera celda.
5. Si la instalación de DuckDB falla, guardá el mensaje y trabajá con la pantalla
   compartida del equipo o el diccionario Excel hasta recibir ayuda.

No modifiques los CSV para “hacer que cierre” un control.

## Uso de IA

Está permitido pedir explicaciones, ejemplos o una revisión de la consulta. El
equipo debe:

- declarar la asistencia;
- compartir solo estos datos sintéticos;
- verificar grano, campos y salida;
- rechazar causas no demostradas;
- poder explicar cada cláusula y cada relación.
