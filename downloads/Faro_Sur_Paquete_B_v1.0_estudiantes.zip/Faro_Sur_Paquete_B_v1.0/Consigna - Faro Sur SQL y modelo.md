# Consigna — Faro Sur: SQL y modelo relacional

## Situación

La tabla inicial de Faro Sur era fácil de leer, pero repetía nombres de clientes,
productos y pedidos. El equipo de datos decidió separar el núcleo comercial en
cuatro tablas y ofrecer una vista preparada para análisis.

La dirección necesita respuestas reproducibles sobre volumen, ventas y margen. Antes
de responder, el equipo debe demostrar que comprende el grano y que sus relaciones
no alteran los totales.

## Objetivos

Al completar el paquete, el equipo podrá:

- reconocer entidades, granos y claves;
- formular preguntas mediante SQL inicial;
- diferenciar filas, pedidos y clientes;
- construir joins muchos-a-uno;
- reconciliar una vista contra sus tablas de origen;
- comunicar una observación sin convertirla en causalidad.

## Organización

Trabajen en equipos de 3 a 5 personas y roten estos roles:

| Rol | Responsabilidad |
|---|---|
| Navegación | ejecuta el notebook y comparte pantalla |
| Modelo | vigila grano, claves y relaciones |
| Auditoría | compara conteos e importes |
| Negocio | conecta la salida con una decisión |
| Relatoría | registra consulta, evidencia y límites |

Si son tres integrantes, combinen navegación con relatoría y modelo con auditoría.

## Incremento 1 — modelo conceptual

Antes de SQL:

1. expliquen el grano de cada tabla;
2. marquen las tres claves primarias;
3. identifiquen las tres claves foráneas;
4. lean cada relación en ambos sentidos;
5. indiquen dónde debería vivir cada atributo:
   `region`, `order_date`, `family`, `quantity`;
6. expliquen por qué la vista no reemplaza el modelo.

### Evidencia

Un diagrama comentado o una captura con cinco anotaciones y una frase sobre el grano
más detallado.

## Incremento 2 — SQL sobre la vista

Completen el notebook `Faro_Sur_02_SQL_sobre_una_vista.ipynb`.

El equipo debe producir tres consultas:

1. ventas y margen por una dimensión;
2. pedidos y ventas para un filtro elegido;
3. evolución mensual de una medida.

Para una de ellas, documenten:

- pregunta;
- consulta;
- salida;
- observación con un valor;
- hipótesis;
- dato faltante antes de decidir.

### Mínimo técnico

- usar `SELECT` y `FROM`;
- incluir al menos un `WHERE`;
- incluir al menos un `GROUP BY`;
- usar `COUNT(DISTINCT ...)` cuando la unidad no sea una fila;
- ordenar una salida.

## Incremento 3 — joins controlados

Completen `Faro_Sur_03_Modelo_y_joins_controlados.ipynb`.

1. unan pedidos con clientes;
2. unan líneas con productos;
3. construyan el detalle de cuatro tablas;
4. controlen filas después de cada paso;
5. reconcilien venta y margen con `vw_ventas`;
6. obtengan ventas netas por segmento;
7. identifiquen los cinco clientes con mayor venta;
8. expliquen qué nueva tabla pedirían para estudiar cumplimiento de entregas.

### Control obligatorio

La salida final debe conservar 7.500 líneas y totalizar:

- venta neta: USD 32.825.861,00;
- margen bruto: USD 9.038.105,00.

## Evidencia para el proyecto final

El patrón se transfiere al caso del equipo:

1. lista de fuentes;
2. grano de cada entidad;
3. claves o reglas de vinculación;
4. tres preguntas analíticas;
5. una consulta o pseudoconsulta;
6. un control para detectar duplicaciones;
7. un trade-off del modelo.

Esta evidencia alimenta la presentación intermedia 1 del 23/09. No se exige que el
caso propio ya tenga una implementación completa.

## Criterios de cumplimiento

| Criterio | Evidencia observable |
|---|---|
| Grano | explica correctamente una fila en cada tabla |
| Claves | distingue primaria y foránea |
| SQL | adapta una consulta sin perder la unidad de análisis |
| Join | puede leer la condición `ON` |
| Control | reconcilia filas e importes |
| Interpretación | separa observación de hipótesis |
| Participación | cada integrante puede explicar una parte |

No se evalúa escribir toda la sintaxis de memoria.
