# Modelo relacional — Faro Sur, Paquete B

```mermaid
erDiagram
    CUSTOMERS ||--o{ SALES_ORDERS : "realiza"
    SALES_ORDERS ||--|{ SALES_ORDER_LINES : "contiene"
    PRODUCTS ||--o{ SALES_ORDER_LINES : "aparece en"

    CUSTOMERS {
        varchar customer_id PK
        varchar customer_name
        varchar segment
        varchar region
    }

    PRODUCTS {
        varchar product_id PK
        varchar product_name
        varchar family
        decimal list_price_usd
        decimal standard_cost_usd
    }

    SALES_ORDERS {
        varchar order_id PK
        varchar order_number
        varchar customer_id FK
        date order_date
        varchar channel
    }

    SALES_ORDER_LINES {
        varchar line_id PK
        varchar order_id FK
        varchar product_id FK
        integer quantity
        decimal unit_price_usd
        decimal discount_pct
    }
```

## Lectura

- Un cliente puede realizar muchos pedidos; cada pedido pertenece a un cliente.
- Un pedido contiene una o más líneas; cada línea pertenece a un pedido.
- Un producto puede aparecer en muchas líneas; cada línea refiere a un producto.
- `PK` significa clave primaria; `FK`, clave foránea.
- El grano más detallado del modelo es una línea por producto dentro de un pedido.
