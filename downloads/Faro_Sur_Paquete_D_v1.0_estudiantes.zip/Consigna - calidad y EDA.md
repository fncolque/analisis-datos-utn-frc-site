# Consigna — Faro Sur: calidad, Python y EDA

## Parte 1 — contrato de calidad

Faro Sur recibió una nueva carga de clientes, despachos y pagos. Antes de actualizar
los indicadores deben ejecutarse cuatro controles.

| Dimensión | Regla |
|---|---|
| unicidad | `shipment_id` identifica un solo despacho |
| completitud | todo cliente tiene una región informada |
| consistencia | unidades despachadas no superan unidades pedidas |
| referencialidad | todo pago pertenece a un pedido existente |

Para cada regla:

1. escribí o adaptá la consulta;
2. guardá resultado y cantidad de afectados;
3. clasificá severidad;
4. indicá qué métrica podría distorsionar;
5. proponé tratamiento;
6. asigná un responsable;
7. explicá si el pipeline debe detenerse o continuar con cuarentena.

## Parte 2 — impacto

Compará unidades y costo de flete:

- antes de deduplicar;
- conservando una fila por `shipment_id`.

Calculá la diferencia absoluta. No asumas que deduplicar siempre significa
“quedarse con cualquiera”: en un sistema real se necesita orden de ingesta o una
regla de precedencia.

## Parte 3 — EDA sobre capa curada

Usá `delivery_analysis_curated.csv` y respondé:

> ¿Dónde aparece una señal operativa que merezca investigación adicional?

La respuesta debe incluir:

- unidad de análisis;
- denominador;
- comparación;
- valor concreto;
- hipótesis;
- explicación alternativa;
- dato faltante.

## Visual obligatorio

Elegí uno:

- barras para comparar OTIF por región;
- barras para comparar despachos parciales por familia;
- boxplot o histograma para observar tiempo de entrega;
- línea para observar evolución mensual.

No usar torta para una métrica temporal ni gráfico 3D.

## Extensión opcional

Compará media, mediana y percentil 90 del tiempo de entrega. Identificá qué pregunta
responde cada estadístico y cuál comunicarías a operaciones.

