# Guía mínima — Python y Pandas

## Qué es Python

Python es un lenguaje de programación. Un notebook permite combinar texto, código
y resultados en celdas. La ejecución conserva estado: si una celda depende de otra,
debe ejecutarse después.

## Qué es Pandas

Pandas es una librería de Python para trabajar con tablas. Su objeto principal es
el `DataFrame`.

```python
import pandas as pd
datos = pd.read_csv("archivo.csv")
```

## Operaciones que se usan

| Código | Pregunta |
|---|---|
| `datos.shape` | ¿cuántas filas y columnas hay? |
| `datos.head()` | ¿cómo se ven las primeras filas? |
| `datos.dtypes` | ¿qué tipo reconoce cada columna? |
| `datos.isna().sum()` | ¿cuántos nulos hay? |
| `datos["line_id"].nunique()` | ¿cuántas claves diferentes hay? |
| `datos.describe()` | ¿cómo se distribuyen las medidas? |
| `datos.groupby(...)` | ¿cómo resumo por una dimensión? |
| `datos.sort_values(...)` | ¿cómo ordeno el resultado? |

## Variable, función y método

- una **variable** conserva una referencia: `delivery = ...`;
- una **función** recibe argumentos: `pd.read_csv(...)`;
- un **método** opera sobre un objeto: `delivery.head()`.

No es necesario memorizar estas categorías para aprobar; sí poder leer qué hace una
línea y comprobar su salida.

## Errores frecuentes

- ejecutar celdas fuera de orden;
- convertir una fecha en texto y luego ordenarla mal;
- usar promedio de porcentajes con denominadores diferentes;
- ignorar nulos porque el código no falla;
- confundir cantidad de filas con cantidad de pedidos;
- interpretar correlación o comparación como causa.

## Uso responsable de IA

Una IA puede:

- explicar una línea;
- proponer una variante;
- revisar un error;
- sugerir un gráfico.

El estudiante debe comprobar nombres de columnas, grano, denominador, salida y
límites. Si el código no puede explicarse, no constituye evidencia.

