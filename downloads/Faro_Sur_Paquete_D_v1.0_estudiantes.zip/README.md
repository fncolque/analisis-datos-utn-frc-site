# Faro Sur — Paquete D: cómo empezar

## Dos prácticas, un solo ZIP

Usarás:

- `datos/datos_faro_sur_d_v1.0.zip`;
- `Faro_Sur_05_Calidad_de_datos.ipynb`;
- `Faro_Sur_06_Python_EDA.ipynb`.

No descomprimas el ZIP. Cada notebook crea una carpeta limpia y carga lo necesario.

## Orden obligatorio

### 1. Calidad

Ejecutá `Faro_Sur_05_Calidad_de_datos.ipynb`.

No abras todavía `delivery_analysis_curated.csv`. Primero:

1. ejecutá las cuatro reglas;
2. medí cuántos registros afectan;
3. estimá el impacto sobre una métrica;
4. decidí tratamiento y responsable;
5. guardá consultas y salidas.

### 2. Python y EDA

Una vez validada la evidencia de calidad, abrí `Faro_Sur_06_Python_EDA.ipynb`.
Ese notebook trabaja con una tabla curada a nivel línea de pedido.

Vas a practicar:

- leer un CSV;
- interpretar filas, columnas y tipos;
- contar nulos y claves;
- resumir con `describe`;
- agrupar con `groupby`;
- construir un gráfico;
- escribir hallazgo, hipótesis y límite.

## Qué no se espera

- memorizar Python;
- programar una aplicación;
- corregir archivos manualmente;
- inferir causas a partir de una comparación;
- usar estadística inferencial o regresión;
- producir muchas visualizaciones.

## Evidencia mínima

### Calidad

- una tabla con regla, resultado, severidad, impacto, tratamiento y responsable;
- una comparación cuantitativa del efecto de duplicados;
- consultas ejecutables.

### EDA

- control de grano;
- resumen por región;
- un gráfico con título y escala correcta;
- un hallazgo con valor;
- una hipótesis;
- un dato adicional necesario.

## Recuperación

Si no podés ejecutar Colab:

1. trabajá con el diccionario;
2. escribí las cuatro consultas en texto;
3. completá el registro de calidad con resultados provistos por tu equipo;
4. explicá oralmente el grano y el impacto;
5. retomá la ejecución fuera de clase.

