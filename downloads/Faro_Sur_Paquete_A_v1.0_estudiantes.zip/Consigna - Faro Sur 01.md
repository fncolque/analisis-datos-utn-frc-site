# Consigna — Faro Sur 01

## Primer contacto con una tabla de negocio

### Situación

Faro Sur Equipamientos S.A. fabrica y distribuye bombas industriales, repuestos y kits de mantenimiento. La dirección observa que algunas decisiones comerciales y operativas se toman con métricas aisladas.

El equipo recibe un extracto limpio de líneas de pedido ya entregadas. Debe construir una primera lectura sin confundir una observación con una explicación causal.

### Objetivos

Al finalizar, el equipo podrá:

- explicar el grano de la tabla;
- distinguir dimensiones, medidas e identificadores;
- construir ventas, costo, margen y cumplimiento mediante celdas preparadas;
- comparar resultados por una dimensión;
- formular una decisión preliminar y señalar qué información falta;
- verificar una explicación producida con asistencia de IA.

### Organización

Trabajen en grupos de 3 a 5 personas. Distribuyan roles:

| Rol | Responsabilidad |
|---|---|
| Navegación | ejecuta las celdas y comparte la pantalla |
| Lectura de negocio | conecta campos y resultados con el caso |
| Auditoría | revisa grano, unidades y controles |
| Relatoría | registra la evidencia de salida |
| Tiempo | ayuda a completar el mínimo antes de las extensiones |

Si el grupo tiene tres integrantes, combinen relatoría y tiempo con otros roles.

### Recorrido mínimo

1. Escriban una hipótesis antes de mirar resultados.
2. Carguen `ventas_inicial.csv`.
3. Confirmen `900 filas × 15 columnas`.
4. Expliquen por qué `pedido` puede repetirse.
5. Clasifiquen los seis campos propuestos.
6. Ejecuten la construcción de métricas.
7. Analicen primero por `familia`.
8. Cambien `DIMENSION` por `region`, `segmento` o `canal`.
9. Redacten observación, interpretación y decisión como tres afirmaciones diferentes.
10. Completen la evidencia de salida.

### Evidencia de salida

Entreguen una respuesta breve con:

1. **Grano:** qué representa una fila.
2. **Observación:** un resultado y su valor.
3. **Interpretación:** una explicación posible, presentada como hipótesis.
4. **Decisión:** una acción preliminar coherente.
5. **Dato faltante:** una fuente que pedirían antes de actuar.

### Uso de IA

Está permitido usar IA para explicar el código o criticar una interpretación. El equipo sigue siendo responsable de:

- verificar la explicación contra la salida ejecutada;
- declarar qué parte fue asistida;
- evitar datos sensibles;
- corregir errores o supuestos inventados;
- poder explicar la respuesta sin leerla.

### Criterio de cumplimiento

La actividad se considera completa cuando el equipo:

- cargó el release correcto;
- explicó el grano;
- produjo al menos una agregación;
- citó un valor concreto;
- distinguió observación, interpretación y decisión;
- identificó un límite de los datos.

La escritura de código no se evalúa en esta instancia.

