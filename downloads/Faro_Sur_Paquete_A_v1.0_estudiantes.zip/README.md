# Faro Sur 01 — cómo empezar

## Qué necesitás

- una notebook personal;
- un navegador actualizado;
- una cuenta Google;
- conexión a internet;
- los archivos de esta carpeta.

No necesitás instalar Python, Power BI ni ninguna base de datos.

## Inicio recomendado

1. Descargá `Faro_Sur_01_Primer_contacto.ipynb`.
2. Ingresá a https://colab.research.google.com/.
3. Elegí **Archivo → Subir notebook** y seleccioná el archivo.
4. Guardá una copia propia en Drive cuando Colab lo solicite.
5. Ejecutá las celdas de arriba hacia abajo con el botón ▶.
6. Cuando aparezca el selector, cargá `datos/ventas_inicial.csv`.
7. Detenete si la salida no indica `900 filas × 15 columnas`.

También podés consultar:

- `Diccionario de datos - Faro Sur - Paquete A v1.0.xlsx`, si querés navegar los campos y una copia de los datos;
- `datos/diccionario_campos.csv`, si preferís un formato liviano.

## Regla de seguridad

El caso es sintético. En trabajos futuros, no cargues en Colab ni pegues en asistentes de IA:

- contraseñas o claves;
- datos personales;
- datos empresariales sin autorización;
- información que no haya sido anonimizada.

## Si algo falla

1. Mostrá el mensaje de error completo.
2. Confirmá que el archivo se llama `ventas_inicial.csv`.
3. Volvé a ejecutar la celda de carga.
4. Si el problema continúa, reiniciá la sesión y ejecutá desde el comienzo.

No hace falta entender todo el código para completar esta primera práctica. Sí hace falta poder explicar qué representa una fila y qué significa cada resultado.

