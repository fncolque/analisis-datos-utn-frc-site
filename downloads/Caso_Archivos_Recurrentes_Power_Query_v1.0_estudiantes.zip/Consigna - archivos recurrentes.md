# Consigna — De adjuntos a una tabla controlada

## Pregunta

¿Cómo consolidar archivos recurrentes sin ocultar cambios de estructura,
duplicados ni registros inválidos?

## Actividad mínima

1. Declarar el grano, la clave y el uso previsto del consolidado.
2. Configurar `param_carpeta` en `Plantilla_Control_Consolidacion.xlsx`.
3. Crear las consultas en el orden indicado por la guía.
4. Actualizar `Control_Archivos`, `Consumos_Curados`,
   `Registros_Rechazados` y `Control_Resultado`.
5. Copiar los controles obtenidos en la hoja `Control`.
6. Explicar el archivo rechazado, la reentrega y dos defectos de calidad.
7. Completar la hoja `Evidencia`.

## Evidencia

La entrega conserva:

- captura o tabla de `Control_Archivos`;
- controles reconciliados;
- un registro aceptado y un registro rechazado;
- explicación de la regla de deduplicación;
- salida consolidada o captura equivalente;
- límite operativo;
- registro de asistencia de IA, si intervino.

## Extensión Power Query

Elegí una modificación:

- agregar una regla para `orden_trabajo` vacía;
- crear un resumen por planta y categoría;
- cambiar la política de reentrega y justificarla;
- incorporar un sexto archivo compatible y predecir los controles antes de
  actualizar.

## Extensión de arquitectura

Compará dos alternativas mediante fuente, disparador, almacenamiento, permisos,
control de fallas y costo de mantenimiento:

| Alternativa | Uso posible |
|---|---|
| Power Query con actualización manual | consolidación periódica operada por una persona |
| Power Automate | guardar adjuntos o ejecutar un flujo por evento o recurrencia |
| Power Apps con SharePoint o Dataverse | capturar datos con validaciones antes de generar archivos |
| Office Scripts | automatizar acciones de Excel e integrarlas con Power Automate |
| VBA | sostener una solución de escritorio o un libro heredado |

## Cierre

Indicá qué condición haría insuficiente la solución con archivos y qué destino de
datos evaluarías después.

