# De adjuntos a una tabla controlada

## Situación

Tres plantas envían consumos de mantenimiento mediante archivos Excel. El área de
planificación necesita una tabla consolidada para revisar importes, materiales y
órdenes de trabajo. El proceso debe soportar una reentrega y separar registros que
incumplen reglas conocidas.

Cada fila representa un consumo de material imputado a una orden de trabajo. La
clave esperada es `movimiento_id`.

## Archivos

- `datos/01_raw`: cinco adjuntos sintéticos;
- `Plantilla_Control_Consolidacion.xlsx`: ruta, controles, diccionario y evidencia;
- `consultas_power_query`: consultas M preparadas y numeradas;
- `Guía paso a paso - Power Query.md`: configuración y ejecución;
- `Consigna - archivos recurrentes.md`: evidencia mínima y extensiones;
- `manifest_caso_archivos_recurrentes.json`: versión, tamaño y hash de cada Excel.

## Control de entrada

Antes de transformar:

1. verificá que existan cinco archivos en `datos/01_raw`;
2. conservá nombres y contenido;
3. abrí la plantilla y reemplazá la ruta de `param_carpeta`;
4. registrá qué representa una fila y cuál es la clave;
5. anticipá qué debería ocurrir con una reentrega.

## Resultado esperado

La práctica produce tres salidas:

- `Control_Archivos`: archivo aceptado o rechazado y columnas faltantes;
- `Consumos_Curados`: registros únicos que cumplen las reglas;
- `Registros_Rechazados`: defectos y duplicados con un motivo explícito.

El proceso queda listo cuando los valores de `Control_Resultado` coinciden con la
hoja `Control` de la plantilla y el equipo puede explicar cada diferencia.

## Recuperación

Si Power Query no está disponible, utilizá la hoja `Control`, el diccionario y las
capturas provistas por el docente. Completá la evidencia a partir del recorrido y
documentá qué paso no pudiste ejecutar.

