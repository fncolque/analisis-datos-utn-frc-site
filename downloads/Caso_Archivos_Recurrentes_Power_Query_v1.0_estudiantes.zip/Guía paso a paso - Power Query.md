# Guía paso a paso — Power Query

## 1. Preparar una copia

1. Descomprimí el paquete en una ruta corta.
2. Conservá `datos/01_raw` sin cambios.
3. Abrí `Plantilla_Control_Consolidacion.xlsx`.
4. Guardá una copia con el identificador de tu equipo.
5. En la hoja `Inicio`, reemplazá la ruta de la tabla `param_carpeta` por la
   ubicación completa de `datos/01_raw`.

## 2. Crear las consultas

En Excel, abrí **Datos → Obtener datos → Desde otras fuentes → Consulta en
blanco**. Para cada archivo de `consultas_power_query`:

1. abrí el Editor avanzado;
2. reemplazá el contenido por el código del archivo;
3. confirmá;
4. asigná a la consulta el nombre indicado en la primera línea del comentario;
5. continuá con el archivo siguiente.

Orden:

| Archivo | Nombre de consulta | Carga |
|---|---|---|
| `00 - ParametroCarpeta.pq` | `ParametroCarpeta` | solo conexión |
| `01 - fxLeerConsumos.pq` | `fxLeerConsumos` | solo conexión |
| `02 - Archivos.pq` | `Archivos` | solo conexión |
| `03 - Control_Archivos.pq` | `Control_Archivos` | tabla |
| `04 - Consumos_Base.pq` | `Consumos_Base` | solo conexión |
| `05 - Consumos_Curados.pq` | `Consumos_Curados` | tabla |
| `06 - Registros_Rechazados.pq` | `Registros_Rechazados` | tabla |
| `07 - Control_Resultado.pq` | `Control_Resultado` | tabla |

Para definir la carga, usá **Cerrar y cargar en…**. Las consultas intermedias
quedan como conexión; las cuatro salidas visibles se cargan en hojas nuevas.

## 3. Leer `Control_Archivos`

Verificá:

- cantidad de archivos detectados;
- cantidad de archivos procesables;
- archivo rechazado;
- columna obligatoria ausente;
- filas declaradas por cada archivo.

El archivo rechazado permanece en raw. El control registra por qué no avanza.

## 4. Inspeccionar `Consumos_Base`

Abrí la consulta y localizá los pasos:

- combinación de tablas válidas;
- normalización de textos;
- tipado de fechas y números;
- orden por fecha de recepción;
- índice dentro de cada `movimiento_id`;
- construcción de `motivo_rechazo`;
- asignación de `estado_registro`.

Buscá `MOV-0012`. La versión del archivo más reciente se conserva y la versión
anterior queda marcada como duplicada.

## 5. Reconciliar

Actualizá `Control_Resultado` y copiá cada valor en la columna `Actual` de la hoja
`Control`.

Investigá todo estado `REVISAR` mediante este orden:

1. ruta y cantidad de archivos;
2. nombre de tabla `tbl_consumos`;
3. columnas requeridas;
4. tipos;
5. regla de duplicados;
6. filtros de aceptación.

## 6. Agregar una nueva entrega

Duplicá un archivo procesable fuera de `01_raw`, modificá sus identificadores y
fechas, y guardalo con el patrón `consumos_aaaa-mm-dd.xlsx`. Antes de copiarlo a
raw, predecí cómo cambiarán filas e importe. Actualizá y compará la predicción.

## 7. Transferir el patrón

Completá la hoja `Evidencia` con una tarea laboral. Anonimizá nombres, correos,
rutas internas, identificadores personales y valores confidenciales.

## Fuentes de consulta

- <https://learn.microsoft.com/power-query/connectors/folder>
- <https://learn.microsoft.com/power-query/combine-files-overview>
- <https://learn.microsoft.com/power-automate/email-triggers>
- <https://learn.microsoft.com/power-apps/maker/canvas-apps/add-data-connection>
- <https://learn.microsoft.com/office/dev/scripts/develop/power-automate-integration>
- <https://learn.microsoft.com/es-es/office/dev/scripts/resources/vba-differences>
