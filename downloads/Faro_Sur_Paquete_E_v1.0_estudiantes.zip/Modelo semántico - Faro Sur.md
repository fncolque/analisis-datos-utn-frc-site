# Modelo semántico — Faro Sur

```mermaid
erDiagram
    DIM_CUSTOMERS ||--o{ MART_SALES : customer_id
    DIM_CUSTOMERS ||--o{ MART_DELIVERIES : customer_id
    DIM_PRODUCTS ||--o{ MART_SALES : product_id
    DIM_PRODUCTS ||--o{ MART_DELIVERIES : product_id
    DIM_PRODUCTS ||--o{ MART_INVENTORY : product_id
    DIM_DATE ||--o{ MART_SALES : order_date
    DIM_DATE ||--o{ MART_DELIVERIES : delivered_date
    DIM_DATE ||--o{ MART_INVENTORY : snapshot_date
```

## Relaciones

| Desde | Hacia | Cardinalidad | Dirección |
|---|---|---|---|
| `mart_sales[customer_id]` | `dim_customers[customer_id]` | muchos a uno | dimensión → mart |
| `mart_sales[product_id]` | `dim_products[product_id]` | muchos a uno | dimensión → mart |
| `mart_sales[order_date]` | `dim_date[date]` | muchos a uno | dimensión → mart |
| `mart_deliveries[customer_id]` | `dim_customers[customer_id]` | muchos a uno | dimensión → mart |
| `mart_deliveries[product_id]` | `dim_products[product_id]` | muchos a uno | dimensión → mart |
| `mart_deliveries[delivered_date]` | `dim_date[date]` | muchos a uno | dimensión → mart |
| `mart_inventory[product_id]` | `dim_products[product_id]` | muchos a uno | dimensión → mart |
| `mart_inventory[snapshot_date]` | `dim_date[date]` | muchos a uno | dimensión → mart |

## Decisiones

- No se relacionan marts entre sí.
- El filtro es unidireccional desde dimensión.
- Cada mart conserva su grano.
- La fecha activa representa la lectura principal de cada proceso.
- Otras fechas se mantienen como columnas, pero no se agregan relaciones activas en
  esta primera versión.

