# Guía paso a paso — Power BI

## 0. Antes de abrir Power BI

Ejecutá `Faro_Sur_07_Control_modelo_semantico.ipynb` y dibujá el storyboard. No
empieces arrastrando campos.

## 1. Preparar los archivos

1. Descomprimí `datos/datos_faro_sur_e_v1.0.zip` en una carpeta propia.
2. No cambies nombres ni contenido.
3. Abrí Power BI Desktop.
4. Creá un archivo nuevo y guardalo como `Faro_Sur_Equipo_XX.pbix`.

## 2. Importar

Usá **Obtener datos → Texto/CSV** para:

- `dim_customers.csv`;
- `dim_products.csv`;
- `dim_date.csv`;
- `mart_sales.csv`;
- `mart_deliveries.csv`;
- `mart_inventory.csv`.

Elegí **Transformar datos** para comprobar tipos.

## 3. Tipos en Power Query

### Texto

- todas las claves terminadas en `_id`;
- `order_number`;
- `channel`, `region`, `segment`, `family`, `warehouse_id`;
- `year_month`, `month_name`, `quarter`.

### Fecha

- `date`;
- `order_date`;
- `promised_date`;
- `shipped_date`;
- `delivered_date`;
- `snapshot_date`.

### Número entero

- cantidades;
- flags 0/1;
- conteos;
- `year`, `month_number`, `year_month_order`.

### Decimal

- importes;
- porcentajes almacenados como proporción;
- `coverage_months`.

No elimines filas ni reemplaces valores: esta capa ya está curada.

## 4. Aplicar y revisar

Elegí **Cerrar y aplicar**. En la vista de datos:

- comprobá 120 clientes;
- comprobá 30 productos;
- comprobá 7.500 filas en `mart_sales`;
- comprobá 7.500 filas en `mart_deliveries`.

## 5. Crear relaciones

En vista Modelo, creá las relaciones descriptas en
`Modelo semántico - Faro Sur.md`.

Configuración:

- cardinalidad muchos-a-uno desde mart hacia dimensión;
- dirección de filtro simple desde dimensión hacia mart;
- relación activa;
- no relaciones directas entre marts.

Si Power BI crea una relación no documentada, revisala o eliminála.

## 6. Tabla fecha

Seleccioná `dim_date[date]` como columna de fecha. Ordená:

- `month_name` por `month_number`;
- `year_month` por `year_month_order`.

Esto evita orden alfabético de meses.

## 7. Crear medidas

Copiá una medida por vez desde `Medidas de referencia.dax`.

Después de cada medida:

1. agregala a una tarjeta o tabla;
2. compará con el notebook;
3. formateá moneda, entero o porcentaje;
4. recién entonces creá la siguiente.

No uses una columna de margen porcentual agregada como promedio. El margen se
calcula dividiendo margen total por venta total.

## 8. Construir la página

Orden sugerido:

1. título y pregunta;
2. cuatro tarjetas;
3. tendencia de venta por `dim_date[year_month]`;
4. barras de OTIF por `dim_customers[region]`;
5. segmentador por `dim_products[family]`;
6. nota de definición.

Usá fondo claro, texto oscuro y un color de énfasis. Reservá amarillo para alertas
puntuales. Evitá 3D, decoraciones, demasiados bordes y leyendas redundantes.

## 9. Reconciliar

Creá una página temporal `00_Control` con:

- filas de venta;
- pedidos;
- ventas netas;
- margen bruto;
- filas de entrega;
- OTIF.

No ocultes la página hasta que todos los valores coincidan.

## 10. Escribir la historia

Estructura:

- **hallazgo:** valor y comparación;
- **hipótesis:** mecanismo posible, no probado;
- **acción:** decisión reversible;
- **límite:** dato o supuesto faltante.

Ejemplo:

> Patagonia muestra menor OTIF de líneas que Centro. Conviene revisar promesas y
> rutas para kits, pero la comparación no aísla distancia, depósito ni
> transportista.

## macOS

Power BI Desktop no se instala de forma nativa en macOS. El equipo debe organizar
una sesión compartida sobre la computadora Windows. Quienes usan macOS realizan
controles en Colab, redactan medidas, diseñan el storyboard y revisan la página.

Fuentes de consulta:

- <https://learn.microsoft.com/power-bi/transform-model/desktop-create-and-manage-relationships>
- <https://learn.microsoft.com/power-bi/transform-model/desktop-measures>

