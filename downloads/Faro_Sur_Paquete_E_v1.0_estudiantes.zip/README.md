# Faro Sur — Paquete E: cómo empezar

## Archivos principales

- `datos/datos_faro_sur_e_v1.0.zip`: todas las tablas;
- `Faro_Sur_07_Control_modelo_semantico.ipynb`: validación accesible en Colab;
- `Guía paso a paso - Power BI.md`: construcción del reporte;
- `Modelo semántico - Faro Sur.md`: relaciones;
- `Medidas de referencia.dax`: medidas básicas;
- `Consigna - reporte de decisión.md`: evidencia esperada.

## Orden recomendado

1. Ejecutar el notebook de control.
2. Confirmar conteos y totales.
3. Elegir audiencia y decisión.
4. Dibujar la página antes de abrir Power BI.
5. Importar las seis tablas.
6. Configurar tipos y relaciones.
7. Crear medidas.
8. Construir una página.
9. Reconciliar.
10. Realizar crítica entre pares.

## Reparto de roles

Un equipo de cuatro puede distribuir:

- control y reconciliación;
- modelo y relaciones;
- medidas;
- diseño y narrativa.

Los roles deben rotar al explicar el resultado. Todos los integrantes deben poder
explicar al menos una relación, una medida y una decisión visual.

## Requisitos

- una computadora Windows con Power BI Desktop por equipo para el armado;
- Google Colab para el control común;
- acceso a los archivos del paquete;
- no se requiere Gateway, licencia Pro ni publicación pública.

## Criterio de éxito

La página no se considera correcta porque “se ve bien”. Debe:

- responder una pregunta;
- respetar el grano;
- usar medidas reconciliadas;
- evitar escalas o denominadores engañosos;
- distinguir evidencia de hipótesis;
- revelar una acción posible y su límite.

