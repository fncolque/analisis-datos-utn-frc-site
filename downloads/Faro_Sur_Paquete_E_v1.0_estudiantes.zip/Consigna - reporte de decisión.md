# Consigna — Faro Sur: una página para decidir

## Audiencia

Elegí una:

- Dirección General;
- Gerencia Comercial;
- Gerencia de Operaciones;
- Gerencia de Supply Chain.

## Decisión

Completá:

> Al finalizar esta página, **[audiencia]** debería poder decidir **[acción]**
> observando **[métricas]**, con la precaución de **[límite]**.

## Página obligatoria

La página debe contener:

1. cuatro KPI como máximo;
2. una tendencia temporal;
3. una comparación entre categorías;
4. un segmentador;
5. un título que exprese la pregunta;
6. una nota de alcance o definición.

## Métricas mínimas

Incluir al menos:

- ventas netas;
- margen bruto o margen porcentual;
- OTIF de líneas;
- tiempo de entrega o despachos parciales.

Inventario es una extensión válida, no una obligación.

## Controles

Antes de interpretar:

- 7.500 líneas de venta;
- 3.574 pedidos;
- USD 32.825.861 de venta neta;
- USD 9.038.105 de margen bruto;
- 7.500 líneas de entrega;
- 75,19 % de líneas OTIF.

Si un resultado difiere, el equipo debe revisar filtros, relación, agregación y
tipo de dato.

## Entrega

- archivo `.pbix`;
- captura o exportación de la página;
- tabla de reconciliación;
- párrafo de hasta 150 palabras con hallazgo, hipótesis, acción y límite;
- registro de contribuciones;
- registro de asistencia de IA.

## Crítica entre pares

Otro equipo debe poder responder:

- ¿qué decisión habilita?
- ¿qué visual sobra?
- ¿qué denominador no está visible?
- ¿qué afirmación excede la evidencia?
- ¿qué cambiarían para una audiencia distinta?

