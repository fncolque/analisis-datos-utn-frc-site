# Faro Sur — Paquete C: cómo empezar

## Qué necesitás

- una cuenta Google y acceso a Google Colab;
- el archivo `datos/datos_faro_sur_c_v1.0.zip`;
- el notebook `Faro_Sur_04_API_JSON_ETL.ipynb`;
- entre 75 y 100 minutos de trabajo concentrado.

No necesitás instalar Python, crear una cuenta cloud, configurar una base de datos
ni obtener una clave de API.

## Antes de ejecutar

1. Leé la [consigna](<Consigna - Faro Sur proceso y API.md>).
2. Abrí `datos/data_dictionary.csv` y localizá las tablas nuevas.
3. Dibujá en papel qué relación esperás entre pedido, línea y despacho.
4. Conservá intacto el ZIP: el notebook lo descomprime por vos.

## Recorrido

1. Entrá a <https://colab.research.google.com/>.
2. Elegí **Archivo → Subir notebook**.
3. Subí `Faro_Sur_04_API_JSON_ETL.ipynb`.
4. Guardá una copia propia en Drive.
5. Ejecutá las celdas de arriba hacia abajo.
6. Cuando se abra el selector, cargá solamente
   `datos_faro_sur_c_v1.0.zip`.
7. Detenete si el snapshot no informa 500 despachos.
8. Completá la actividad en el mismo notebook o en la plantilla de evidencia.

## Qué representa cada archivo de datos

| Archivo | Grano |
|---|---|
| `customers.csv` | una fila por cliente |
| `products.csv` | una fila por producto |
| `sales_orders.csv` | una fila por pedido |
| `sales_order_lines.csv` | una fila por producto dentro de un pedido |
| `shipments.csv` | una fila por despacho de una línea |
| `inventory_snapshots.csv` | una fila por mes, depósito y producto |
| `payments.csv` | una fila por pago o cuota confirmada |
| `tracking_api_snapshot.json` | un documento con metadata y 500 despachos anidados |

## Controles esperados del notebook

| Control | Esperado |
|---|---:|
| Registros declarados en metadata | 500 |
| Filas de staging de despachos | 500 |
| Claves de despacho diferentes | 500 |
| Eventos | 2.000 |
| Eventos sin despacho | 0 |

## Si algo falla

1. Leé el último error completo.
2. Confirmá que cargaste el ZIP del Paquete C, no el del Paquete B.
3. Reiniciá la sesión y ejecutá desde la primera celda.
4. Si la instalación de DuckDB falla, conservá una captura del error y avanzá con
   el dibujo de capas y el diccionario.
5. No modifiques el JSON ni un CSV para forzar un resultado.

## Evidencia mínima

Entregá:

- un diagrama fuente → raw → staging → mart;
- el grano de las dos tablas derivadas del JSON;
- una captura o tabla con los cinco controles;
- dos reglas de contrato propuestas;
- una comparación razonada entre ETL y ELT;
- el registro de asistencia de IA, si la utilizaste.

