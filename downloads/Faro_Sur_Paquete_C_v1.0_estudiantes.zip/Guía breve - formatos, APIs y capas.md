# Guía breve — formatos, APIs y capas

## Formato no es contenido

El mismo dato puede representarse de varias formas:

| Formato | Fortaleza | Riesgo común |
|---|---|---|
| CSV | simple, tabular, legible | tipos y relaciones no quedan garantizados |
| JSON | representa objetos y listas | el anidamiento puede ocultar el grano |
| Excel | útil para revisión manual | cambios manuales y versiones divergentes |
| Parquet | eficiente para análisis a escala | menos accesible para inspección inicial |

En esta materia se usa CSV para tablas y JSON para observar un intercambio
semiestructurado. Parquet se reconoce, pero no es un requisito práctico.

## Qué es una API

Una API es un contrato de interacción entre sistemas. Suele definir:

- endpoint o recurso;
- parámetros;
- autenticación;
- estructura de respuesta;
- errores;
- límites de uso;
- paginación;
- versión.

El snapshot del curso conserva una respuesta para que todos trabajen con el mismo
estado. Una demostración en vivo puede fallar por conectividad, permisos o cambios
del proveedor; por eso no es una dependencia evaluable.

## Cuatro capas mínimas

| Capa | Pregunta | Ejemplo |
|---|---|---|
| fuente | ¿qué emitió el sistema? | respuesta de tracking |
| raw | ¿qué recibimos exactamente? | JSON con fecha de extracción |
| staging | ¿cómo tipamos y ordenamos? | tablas de despachos y eventos |
| mart | ¿qué necesita la decisión? | cumplimiento por línea o región |

Raw no significa “malo” y mart no significa “verdadero para siempre”. Cada capa
tiene un propósito y controles distintos.

## ETL y ELT

- **ETL:** extraer, transformar y luego cargar.
- **ELT:** extraer, cargar y transformar dentro de la plataforma de datos.

No existe una respuesta universal. Validaciones de seguridad o contrato pueden
ocurrir antes de cargar; transformaciones analíticas suelen beneficiarse de
preservar raw y ejecutarse de manera reproducible después.

## Qué registrar

- origen y fecha de extracción;
- versión del contrato;
- cantidad de registros recibidos;
- campos obligatorios;
- clave y grano;
- reglas fallidas;
- transformaciones y versión del código;
- destino y consumidores.

