# Consigna — Faro Sur: proceso, API y ETL/ELT

## Situación

La dirección comercial de Faro Sur conoce ventas y margen, pero no puede explicar
por qué una promesa de entrega se cumple o se incumple. Operaciones propone integrar
datos del sistema de tracking, inventario y cobranzas.

El equipo no debe construir un sistema productivo. Debe describir cómo convertir
fuentes heterogéneas en datos confiables y analizables.

## Pregunta guía

> ¿Qué capas, transformaciones y controles necesita Faro Sur para integrar tracking
> con el núcleo comercial sin perder significado ni trazabilidad?

## Parte A — reconocer fuentes y granos

Para cada archivo:

1. indicá qué sistema podría originarlo;
2. escribí qué representa una fila;
3. identificá su clave;
4. marcá si es dato maestro, transaccional, evento o snapshot;
5. indicá con qué tabla se relaciona.

## Parte B — interpretar el JSON

En el notebook:

1. identificá metadata, objetos anidados y listas;
2. explicá la diferencia entre despacho y evento;
3. aplaná despachos y eventos en tablas separadas;
4. verificá conteos y claves;
5. no unas ambas tablas hasta declarar el grano resultante.

## Parte C — diseñar el pipeline

Dibujá como mínimo:

```text
fuente → raw → staging → mart → consumo
```

En cada flecha anotá:

- transformación;
- control;
- responsable;
- evidencia que conservarías;
- frecuencia tentativa.

## Parte D — trade-off

Elegí una de estas decisiones y justificála:

- validar una regla antes o después de cargar;
- consultar una API en vivo o trabajar con snapshots;
- conservar JSON raw o guardar únicamente tablas aplanadas;
- ejecutar transformación propia o usar una herramienta SaaS.

## Entrega mínima

- 1 diagrama;
- 1 tabla breve de fuentes y granos;
- 5 controles ejecutados;
- 2 reglas de contrato;
- 1 trade-off con criterio, alternativa y límite.

## Extensión opcional

Relacioná el snapshot con clientes y calculá cuántos despachos incluye por región.
Explicá por qué esos 500 despachos no representan necesariamente todo el histórico.

