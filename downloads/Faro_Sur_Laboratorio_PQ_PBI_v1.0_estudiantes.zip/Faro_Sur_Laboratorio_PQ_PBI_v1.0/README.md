# Faro Sur — Laboratorio Power Query y Power BI

Datos de Faro Sur del primer trimestre de 2025 para practicar en Power Query y
Power BI: anexar, combinar archivos de una carpeta, dar forma a reportes,
limpiar texto, corregir tipos, crear columnas condicionales, combinar consultas
(joins), agrupar y relacionar tablas en un modelo.

## Archivos

| Archivo | Una fila por | Filas |
|---|---|---:|
| `datos/ventas_mensuales/ventas_2025_01.csv` | línea de pedido | 20 |
| `datos/ventas_mensuales/ventas_2025_02.csv` | línea de pedido | 17 |
| `datos/ventas_mensuales/ventas_2025_03.csv` | línea de pedido | 21 |
| `datos/extras/ventas_2025_04_nuevo_formato.csv` | línea de pedido | 13 |
| `datos/customers.csv` | cliente | 12 |
| `datos/maestros_faro_sur.xlsx`, hoja `productos` | producto | 12 |
| `datos/maestros_faro_sur.xlsx`, hoja `regiones` | región | 4 |
| `datos/contactos_clientes.csv` | contacto de cliente | 14 |
| `datos/pagos_2025_T1.csv` | pago o cuota | 31 |
| `datos/stock_depositos_2025_T1.xlsx`, hoja `Stock` | reporte con formato de impresión | 19 |

## Columnas de ventas

| Columna | Contenido |
|---|---|
| `line_id` | identificador de la línea |
| `order_id` | identificador del pedido; un pedido puede tener varias líneas |
| `order_date` | fecha del pedido (`AAAA-MM-DD`) |
| `customer_id` | cliente, se relaciona con `customers.csv` |
| `product_id` | producto, se relaciona con la hoja `productos` |
| `channel` | canal de venta |
| `quantity` | unidades |
| `unit_price_usd` | precio unitario en dólares |
| `discount_pct` | descuento en puntos porcentuales: `5` significa 5 % |

Venta neta de una línea: `quantity × unit_price_usd × (1 − discount_pct / 100)`.

## Otras fuentes

- `contactos_clientes.csv`: un contacto por cliente, cargado a mano. Tiene
  nombre, cargo, correo, teléfono, ciudad y provincia, CUIT y fecha de alta.
- `pagos_2025_T1.csv`: pagos exportados por un sistema configurado en inglés.
  Se relaciona con las ventas por `order_id`.
- `stock_depositos_2025_T1.xlsx`: unidades al cierre de cada mes por depósito y
  producto, tal como sale del sistema para imprimir.

## Antes de empezar

1. Copiá la carpeta `datos` a una ruta corta, por ejemplo `C:\FaroSur\datos\`.
2. Dejá el archivo de abril en `extras` hasta que la actividad indique moverlo.
3. Comprobá la cantidad de filas de cada archivo contra la tabla de arriba.

Los datos tienen inconsistencias a propósito. Encontrarlas forma parte de la
práctica.

## Para trabajar

Abrí `stock_depositos_2025_T1.xlsx` en Excel antes de cargarlo. ¿Qué tendría
que cambiar en esa hoja para que cada fila sea una observación con depósito,
producto, fecha y unidades?
